#!/bin/bash
export PATH=/usr/bin:/bin:/sbin:/usr/sbin
echo "127.0.0.1      appldnld.apple.com" >> /etc/hosts
echo "127.0.0.1      mesu.apple.com" >> /etc/hosts
echo "127.0.0.1		 appldnld.apple.com.edgesuite.net" >> /etc/hosts